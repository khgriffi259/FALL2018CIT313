<?php

class _404Controller extends Controller{
  
	public function index(){

	}
	
}

?>