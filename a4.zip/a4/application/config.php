<?php
define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:23641/CIT313/FA2018/a4/');

//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'kyhgriff');
define('DB_PASS', 'kyhgriff');
define('DB_NAME', 'kyhgriff_db');