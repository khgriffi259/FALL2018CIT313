<?php

define('ABSOLUTE_PATH', '/home/kyhgriff/htdocs/CIT313/FA2018/a1/CIT_FALL_2018-master/Debug-Exercise-master');
define('URL_ROOT', 'http://corsair.cs.iupui.edu:23641/CIT313/FA2018/a1/CIT_FALL_2018-master/Debug-Exercise-master');