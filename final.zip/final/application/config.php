<?php
define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:23641/CIT313/FA2018/final/');
// define('BASE_URL', '/final/');

//corsair database info
define('DB_HOST', 'localhost');
define('DB_USER', 'kyhgriff');
define('DB_PASS', 'kyhgriff');
define('DB_NAME', 'kyhgriff_db');

//lcoal database info
// define('DB_HOST', 'localhost');
// define('DB_PASS', 'root');
// define('DB_USER', 'root');
// define('DB_NAME', 'kyhgriff_db');