<?php 

    echo $response;

?>